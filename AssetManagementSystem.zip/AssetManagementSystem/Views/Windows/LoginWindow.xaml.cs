﻿using AssetManagementSystem.ViewModels;
using System.Windows;

namespace AssetManagementSystem.Views.Windows
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
    }
}